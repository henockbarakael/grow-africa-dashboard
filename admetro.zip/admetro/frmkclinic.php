<!DOCTYPE html>
<?php
require_once 'core/init.php';
if (Session::exists('home')) {
  echo Session::flash('home');
}
$user = new User();
if (!$user->isLoggedIn()) {
  Redirect::to('index.php');
}
$_SESSION['isActivePage'] = 'admin_dashboard';
$_SESSION['page_actuel'] = 'Dashboard';
$sql = "SELECT COUNT(*) as nombre, sexe FROM retenus GROUP BY sexe";
$result = DB::getInstance()->query($sql)->result();
if (isset($result)) {
  foreach ($result as $value) {
      $enfant_all= $value->nombre;
    if  ($value->sexe=='F') {
      $fille_all = $value->nombre;
    }
    elseif  ($value->sexe=='M') {
      $garçon_all = $value->nombre;
    }  					
  }
  $enfant_all = $fille_all + $garçon_all;
  $percent_f = round(($fille_all * 100)/$enfant_all, 2);
  $percent_g = round(($garçon_all * 100)/$enfant_all, 2);		
}
$age= "SELECT COUNT(*) as nombre, sexe, date_depot, age FROM retenus  GROUP BY sexe, date_depot, age";
$result2 = DB::getInstance()->query($age)->result();
if (isset($result2)) {
  foreach ($result2 as $value) {
    if ($value->sexe=='M' && $value->age=='15') {
      $garçon_15 = $value->nombre;
    }	
    elseif  ($value->sexe=='M' && $value->age=='16') {
      $garçon_16 = $value->nombre;
    }
    elseif  ($value->sexe=='M' && $value->age=='17') {
      $garçon_17 = $value->nombre;
    }
    elseif  ($value->sexe=='M' && $value->age=='18') {
      $garçon_18 = $value->nombre;
    }
    elseif  ($value->sexe=='M' && $value->age=='19') {
      $garçon_19 = $value->nombre;
    }
    elseif  ($value->sexe=='M' && $value->age=='20') {
      $garçon_20 = $value->nombre;
    }	
    elseif  ($value->sexe=='F' && $value->age=='13') {
      $fille_13 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='14') {
      $fille_14 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='15') {
      $fille_15 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='16') {
      $fille_16 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='17') {
      $fille_17 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='18') {
      $fille_18 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='19') {
      $fille_19 = $value->nombre;
    }	
    elseif  ($value->sexe=='F' && $value->age=='20') {
      $fille_20 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='21') {
      $fille_21 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='22') {
      $fille_22 = $value->nombre;
    }
    elseif  ($value->sexe=='F' && $value->age=='23') {
      $fille_23 = $value->nombre;
    }   					
  }
}
$day3= "SELECT COUNT(*) as nombre, sexe, date_depot FROM retenus  GROUP BY sexe, date_depot";
$result3 = DB::getInstance()->query($day3)->result();
if (isset($result3)) {
  foreach ($result3 as $value) {
    if ($value->sexe=='M'  && $value->date_depot=='05/03/2021') {
      $count_M5 = $value->nombre;
    }	
    elseif  ($value->sexe=='F'  && $value->date_depot=='05/03/2021') {
      $count_F5 = $value->nombre;
    }
    elseif  ($value->sexe=='M'  && $value->date_depot=='06/03/2021') {
      $count_M6 = $value->nombre;
    }	
    elseif  ($value->sexe=='F'  && $value->date_depot=='06/03/2021') {
      $count_F6 = $value->nombre;
    }	
    elseif  ($value->sexe=='M'  && $value->date_depot=='08/03/2021') {
      $count_M8 = $value->nombre;
    }	
    elseif  ($value->sexe=='F'  && $value->date_depot=='08/03/2021') {
      $count_F8 = $value->nombre;
    }
    elseif  ($value->sexe=='M'  && $value->date_depot=='09/03/2021') {
      $count_M9 = $value->nombre;
    }	
    elseif  ($value->sexe=='F'  && $value->date_depot=='09/03/2021') {
      $count_F9 = $value->nombre;
    }
    elseif  ($value->sexe=='M'  && $value->date_depot=='10/03/2021') {
      $count_M10 = $value->nombre;
    }	
    elseif  ($value->sexe=='F'  && $value->date_depot=='10/03/2021') {
      $count_F10 = $value->nombre;
    }	
    elseif  ($value->sexe=='F' ) {
      $fille_all = $value->nombre;
    }
    elseif  ($value->sexe=='M' ) {
      $garçon_all = $value->nombre;
    }	
    elseif  ($value->sexe=='M'  && $value->sexe=='F' ) {
      $enfant_all = $value->nombre;
    }		   					
  }
}
$sql17= "SELECT COUNT(*) as nombre FROM retenus  where age between '15' and '17' and sexe = 'M' order by age desc";
$result17 = DB::getInstance()->query($sql17)->result();
if (isset($result17)) {
  foreach ($result17 as $value) {   
      $G_U17 = $value->nombre;
    }	
}
$sql17f= "SELECT COUNT(*) as nombre FROM retenus  where age between '13' and '17' and sexe = 'F' order by age desc";
$result17f = DB::getInstance()->query($sql17f)->result();
if (isset($result17f)) {
  foreach ($result17f as $value) {   
      $F_U17 = $value->nombre;
    }	
}

$sql20f= "SELECT COUNT(*) as nombre FROM retenus  where age between '18' and '25' and sexe = 'F' order by age desc";
$result20f = DB::getInstance()->query($sql20f)->result();

if (isset($result20f)) {
  foreach ($result20f as $value) {   
      $F_U20 = $value->nombre;
    }	
}

$poste= "SELECT COUNT(*) as nombre FROM user_profile  where poste_1= '1' and poste_2= '2' and sexe='M' order by id desc";
$gardien = DB::getInstance()->query($poste)->result();

if (isset($gardien)) {
  foreach ($gardien as $value) {   
      $gardien_m = $value->nombre;
    }	
}

$poste2= "SELECT COUNT(*) as nombre FROM user_profile  where poste_1= '1' and poste_2= '2' and sexe='F' order by id desc";
$gardien2 = DB::getInstance()->query($poste2)->result();

if (isset($gardien2)) {
  foreach ($gardien2 as $value) {   
      $gardien_f = $value->nombre;
    }	
}

$sql20= "SELECT COUNT(*) as nombre FROM retenus where age between '18' and '20' and sexe = 'M' order by age desc";
$result20 = DB::getInstance()->query($sql20)->result();

if (isset($result20)) {
  foreach ($result20 as $value) {   
      $G_U20 = $value->nombre;
    }	
}

$sqlX= "SELECT COUNT(*) as nombre FROM retenus where age='' and sexe = 'M' order by id desc";
$resultX = DB::getInstance()->query($sqlX)->result();

if (isset($resultX)) {
  foreach ($resultX as $value) {   
      $G_UX = $value->nombre;
    }	
}

$sqlY= "SELECT COUNT(*) as nombre FROM retenus where age='' and sexe = 'F' order by id desc";
$resultY = DB::getInstance()->query($sqlY)->result();

if (isset($resultY)) {
  foreach ($resultY as $value) {   
      $F_UY = $value->nombre;
    }	
}
?>
<html lang="en">
<!--<![endif]-->

<!-- Mirrored from seantheme.com/admetro/analytics.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Mar 2021 07:05:59 GMT -->
<head>
<meta charset="utf-8" />
<title>Admetro | Analytics</title>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/css/app.min.css" rel="stylesheet" />


<link href="assets/plugins/jvectormap/jquery-jvectormap.css" rel="stylesheet" />

</head>
<body>

<div id="app" class="app app-header-fixed app-sidebar-fixed">
<div id="app-notification-container" class="app-notification-container">
	<div class="app-notification  bounceInRight animated ">
		<div class="notification-media">
			<i class="fa fa-envelope bg-gradient-blue-indigo text-white"></i>
		</div>
		<div class="notification-info">
			<h4 class="notification-title">Notification</h4>
			<p class="notification-desc"><?php echo "Bonjour"." ".$user->data()->nom." ".$user->data()->prenom." "."et bienvenu!"; ?></p>
		</div>
		<div class="notification-btn single-btn">
			<a href="#" data-dismiss="notification">Close</a>
		</div>
	</div>
</div>
<?php require_once 'components/top-menu.php'; ?>
<?php require_once 'components/sidebar.php'; ?>


<div id="content" class="app-content">

<h1 class="page-header">
Analytics <small>stats, overview & performance</small>
</h1>


<div class="row">

<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats bg-gradient-blue text-white m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">JOUEURS</div>
<div class="widget-stats-value">
<?php 
						if (isset($result)) {
							foreach ($result as $value) {
								if ($value->sexe=='M') {
									$count_M = $value->nombre;
								}										
							}
						echo $count_M;			
					?>
</div>
<div class="widget-stats-desc">RETENUS</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-shopping-bag"></i>
</div>
</a>

</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-purple m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">JOUESES</div>
<div class="widget-stats-value">
<?php 
						
						foreach ($result as $value) {
							if ($value->sexe=='F') {
								$count_F = $value->nombre;
							}										
						}
					echo $count_F;			
				?>
</div>
<div class="widget-stats-desc">RETENUES</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-hand-pointer"></i>
</div>
</a>

</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-pink m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">TAUX DE PARTICIPATION</div>
<div class="widget-stats-value">
<?php echo $percent_g; ?> %
</div>
<div class="widget-stats-desc">Garçons</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-user-astronaut"></i>
</div>
</a>
</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-orange m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">TAUX DE PARTICIPATION</div>
<div class="widget-stats-value">
<?php echo $percent_f; ?> %
</div>
<div class="widget-stats-desc">Filles</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-file-invoice"></i>
</div>
</a>

</div>

</div>


<div class="row">

<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats bg-gradient-blue text-white m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">GARDIENS</div>
<div class="widget-stats-value">
<?php echo $gardien_m; ?>
</div>
<div class="widget-stats-desc">RETENUS</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-shopping-bag"></i>
</div>
</a>

</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-purple m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">GARDIENNES</div>
<div class="widget-stats-value">
<?php echo $gardien_f; ?>
</div>
<div class="widget-stats-desc">RETENUES</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-hand-pointer"></i>
</div>
</a>

</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-pink m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">NEW REGISTERED USER</div>
<div class="widget-stats-value">
<?php echo $percent_g; ?> %
</div>
<div class="widget-stats-desc">Today, 8:20AM</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-user-astronaut"></i>
</div>
</a>
</div>


<div class="col-xl-3 col-sm-6">

<a href="#" class="widget-stats widget-stats-inverse bg-gradient-orange m-b-15">
<div class="widget-stats-info">
<div class="widget-stats-title">PENDING INVOICE</div>
<div class="widget-stats-value">
<?php echo $percent_f; ?> %
</div>
<div class="widget-stats-desc">Yesterday, 10:23PM</div>
</div>
<div class="widget-stats-icon">
<i class="fa fa-file-invoice"></i>
</div>
</a>

</div>

</div>
<div class="row">

<div class="col-xl-4 col-md-6">

<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
OVERVIEW
</h4>
<div class="card-header-btn">
<div class="dropdown dropdown-icon">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>


<div class="card-body">
<div class="text-center p-t-15 p-b-30">
<div class="f-w-600">Right now</div>
<div class="f-s-80 line-height-1 m-xs">
<span data-id="active-user">5</span>
</div>
<div>active users on site</div>
</div>
<hr />
<ul class="list-inline m-b-10 text-center">
<li class="list-inline-item">
<span class="circle circle-sm bg-gradient-blue-purple-to-right m-r-5"></span> Desktop
</li>
<li class="list-inline-item">
<span class="circle circle-sm bg-black-transparent-8 m-r-5"></span> Mobile
</li>
<li class="list-inline-item">
<span class="circle circle-sm bg-muted m-r-5"></span> Tablet
</li>
</ul>
<div class="progress without-rounded-corner m-b-5">
<div class="progress-bar bg-gradient-blue-purple-to-right" data-id="desktop-user" style="width: 60%;">60%</div>
<div class="progress-bar bg-black-transparent-8" data-id="mobile-user" style="width: 25%;">25%</div>
<div class="progress-bar bg-muted" data-id="tablet-user" style="width: 15%;">15%</div>
</div>
<p class="f-s-12 text-muted m-b-0">
* Data updates continuously and each pageview is reported seconds after it occurs.
</p>
</div>

</div>


<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
TOP REFERRALS
</h4>
<div class="card-header-btn">
<div class="dropdown">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>

<table class="table table-bordered table-th-without-border">
<thead>
<tr>
<th width="1%"></th>
<th>Source</th>
<th width="15%" colspan="2" class="text-center text-nowrap">Active Users</th>
</tr>
</thead>
<tbody>
<tr>
<td>1.</td>
<td><a href="#">wrapbootstrap.com</a></td>
<td data-col="value" class="text-right">15</td>
</tr>
<tr>
<td>2.</td>
<td><a href="#">bootswatch.com</a></td>
<td data-col="value" class="text-right">6</td>
</tr>
<tr>
<td>3.</td>
<td><a href="#">google.com</a></td>
<td data-col="value" class="text-right">3</td>
</tr>
<tr>
<td>4.</td>
<td><a href="#">(direct)</a></td>
<td data-col="value" class="text-right">1</td>
</tr>
</tbody>
</table>
</div>


<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
TOP SOCIAL TRAFFIC
</h4>
<div class="card-header-btn">
<div class="dropdown">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>


<table class="table table-bordered table-th-without-border">
<thead>
<tr>
<th width="1%"></th>
<th>Source</th>
<th width="15%" colspan="2" class="text-center text-nowrap">Active Users</th>
</tr>
</thead>
<tbody>
<tr>
<td>1.</td>
<td><a href="#">facebook.com</a></td>
<td data-col="value" class="text-right">5</td>
</tr>
<tr>
<td>2.</td>
<td><a href="#">twitter.com</a></td>
<td data-col="value" class="text-right">3</td>
</tr>
<tr>
<td>3.</td>
<td><a href="#">youtube.com</a></td>
<td data-col="value" class="text-right">1</td>
</tr>
</tbody>
</table>

</div>


<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
TOP KEYWORDS
</h4>
<div class="card-header-btn">
<div class="dropdown">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>


<table class="table table-bordered table-th-without-border">
<thead>
<tr>
<th width="1%"></th>
<th>Keyword</th>
<th width="15%" colspan="2" class="text-center text-nowrap">Active Users</th>
</tr>
</thead>
<tbody>
<tr>
<td>1.</td>
<td><a href="#">admin-template</a></td>
<td data-col="value" class="text-right">5</td>
</tr>
<tr>
<td>2.</td>
<td><a href="#">dashboard</a></td>
<td data-col="value" class="text-right">3</td>
</tr>
<tr>
<td>3.</td>
<td><a href="#">apple-design</a></td>
<td data-col="value" class="text-right">2</td>
</tr>
<tr>
<td>4.</td>
<td><a href="#">bootstrap</a></td>
<td data-col="value" class="text-right">2</td>
</tr>
</tbody>
</table>

</div>

</div>


<div class="col-xl-8 col-md-6">

<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
REAL-TIME MONITORING
</h4>
<div class="switcher switcher-success mt-n1 mb-n1">
<input type="checkbox" name="panel_header_switcher" id="panel_header_switcher" checked="">
<label for="panel_header_switcher"></label>
</div>
</div>


<div class="card-body">
<p class="text-muted f-s-12">
* This is where you monitor user activity as it happens on your site.
</p>
<div style="height: 14.5rem">
<canvas id="page-view-chart"></canvas>
</div>
</div>

</div>


<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
TOP ACTIVE PAGES
</h4>
<div class="card-header-btn">
<div class="dropdown dropdown-icon">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>


<div class="table-responsive">
<table class="table table-bordered table-th-without-border">
<thead>
<tr>
<th width="1%"></th>
<th>Active Page</th>
<th width="15%" colspan="2" class="text-center text-nowrap">Active Users</th>
</tr>
</thead>
<tbody>
<tr>
<td>1.</td>
<td><a href="#">/cloud-boss/index</a></td>
<td data-col="value" width="1%">12</td>
<td data-col="percent">25.00%</td>
</tr>
<tr>
<td>2.</td>
<td><a href="#">/qs1023.asp</a></td>
<td data-col="value">10</td>
<td data-col="percent">20.00%</td>
</tr>
<tr>
<td>3.</td>
<td><a href="#">/search?key=mobile</a></td>
<td data-col="value">8</td>
<td data-col="percent">18.00%</td>
</tr>
<tr>
<td>4.</td>
<td><a href="#">/items/94092</a></td>
<td data-col="value">5</td>
<td data-col="percent">11.11%</td>
</tr>
<tr>
<td>5.</td>
<td><a href="#">/items/93011</a></td>
<td data-col="value">5</td>
<td data-col="percent">11.11%</td>
</tr>
<tr>
<td>6.</td>
<td><a href="#">/home</a></td>
<td data-col="value">4</td>
<td data-col="percent">10.00%</td>
</tr>
<tr>
<td>7.</td>
<td><a href="#">/track</a></td>
<td data-col="value">2</td>
<td data-col="percent">3.00%</td>
</tr>
</tbody>
</table>
</div>

</div>


<div class="card m-b-15">

<div class="card-header">
<h4 class="card-header-title">
TOP LOCATIONS
</h4>
<div class="card-header-btn">
<div class="dropdown dropdown-icon">
<a href="#" class="btn" data-toggle="dropdown"><i class="fa fa-ellipsis-h fa-lg"></i></a>
<div class="dropdown-menu dropdown-menu-right">
<a href="#" class="dropdown-item">Today</a>
<a href="#" class="dropdown-item">Yesterday</a>
<a href="#" class="dropdown-item active">Last 7 days</a>
<a href="#" class="dropdown-item">Last 28 days</a>
</div>
</div>
</div>
</div>

<div class="card-body">
<div id="world-map" style="height: 18rem"></div>
</div>
</div>

</div>

</div>

</div>


<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>

</div>


<div class="theme-panel">
<a href="#" data-click="theme-panel-expand" class="theme-collapse-btn"><i class="fa fa-cog"></i></a>
<div class="theme-panel-content">
<div class="widget-list mb-0">
<div class="widget-list-item">
<div class="widget-list-content">
<div>Color Theme</div>
<div class="theme-list row">
<div class="theme-list-item active"><a href="#" class="bg-silver" data-theme="" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default (Silver)"></a></div>
<div class="theme-list-item"><a href="#" class="bg-red" data-theme="app-theme-red" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Red"></a></div>
<div class="theme-list-item"><a href="#" class="bg-pink" data-theme="app-theme-pink" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Pink"></a></div>
<div class="theme-list-item"><a href="#" class="bg-orange" data-theme="app-theme-orange" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Orange"></a></div>
<div class="theme-list-item"><a href="#" class="bg-yellow" data-theme="app-theme-yellow" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Yellow"></a></div>
<div class="theme-list-item"><a href="#" class="bg-green" data-theme="app-theme-green" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Green"></a></div>
<div class="theme-list-item"><a href="#" class="bg-cyan" data-theme="app-theme-cyan" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Aqua"></a></div>
<div class="theme-list-item"><a href="#" class="bg-blue" data-theme="app-theme-blue" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Blue"></a></div>
<div class="theme-list-item"><a href="#" class="bg-purple" data-theme="app-theme-purple" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Purple"></a></div>
<div class="theme-list-item"><a href="#" class="bg-indigo" data-theme="app-theme-indigo" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Indigo"></a></div>
<div class="theme-list-item"><a href="#" class="bg-black" data-theme="app-theme-black" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Black"></a></div>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
<div>Gradient Theme</div>
<div class="theme-list row">
<div class="theme-list-item"><a href="#" class="bg-gradient-silver" data-theme="app-theme-gradient-silver" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Default (Gradient Silver)"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-red" data-theme="app-theme-gradient-red" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Red"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-pink" data-theme="app-theme-gradient-pink" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Pink"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-orange" data-theme="app-theme-gradient-orange" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Orange"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-yellow" data-theme="app-theme-gradient-yellow" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Yellow"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-green" data-theme="app-theme-gradient-green" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Green"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-cyan" data-theme="app-theme-gradient-cyan" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Aqua"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-blue" data-theme="app-theme-gradient-blue" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Blue"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-purple" data-theme="app-theme-gradient-purple" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Purple"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-indigo" data-theme="app-theme-gradient-indigo" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Indigo"></a></div>
<div class="theme-list-item"><a href="#" class="bg-gradient-black" data-theme="app-theme-gradient-black" data-toggle="theme-selector" data-toggle="tooltip" data-trigger="hover" data-container="body" data-title="Gradient Black"></a></div>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
Fixed Sidebar
</div>
<div class="widget-list-action">
<div class="switcher switcher-success pull-left">
<input type="checkbox" name="sidebar_fixed" id="sidebar_fixed" value="1" checked />
<label for="sidebar_fixed"></label>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
Light Sidebar
</div>
<div class="widget-list-action">
<div class="switcher switcher-success pull-left">
<input type="checkbox" name="sidebar_light" id="sidebar_light" value="1" />
<label for="sidebar_light"></label>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
Fixed Header
</div>
<div class="widget-list-action">
<div class="switcher switcher-success pull-left">
<input type="checkbox" name="header_fixed" id="header_fixed" value="1" checked />
<label for="header_fixed"></label>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
Dark Header
</div>
<div class="widget-list-action">
<div class="switcher switcher-success pull-left">
<input type="checkbox" name="header_dark" id="header_dark" value="1" />
<label for="header_dark"></label>
</div>
</div>
</div>
<div class="widget-list-item">
<div class="widget-list-content">
<a href="#" class="btn btn-silver btn-block btn-rounded btn-sm" data-click="reset-theme-setting">Reset Setting</a>
</div>
</div>
</div>
</div>
</div>

<?php } ?>
<script src="assets/js/app.min.js" type="c086383a299d59771c4df2a7-text/javascript"></script>


<script src="assets/plugins/chart.js/dist/Chart.min.js" type="c086383a299d59771c4df2a7-text/javascript"></script>
<script src="assets/plugins/jvectormap/jquery-jvectormap.min.js" type="c086383a299d59771c4df2a7-text/javascript"></script>
<script src="assets/plugins/jvectormap/tests/assets/jquery-jvectormap-world-mill-en.js" type="c086383a299d59771c4df2a7-text/javascript"></script>
<script src="assets/js/demo/analytics.demo.js" type="c086383a299d59771c4df2a7-text/javascript"></script>

<script type="c086383a299d59771c4df2a7-text/javascript">
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-53034621-1', 'auto');
	  ga('send', 'pageview');

	</script>
	
<script src="ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="c086383a299d59771c4df2a7-|49" defer=""></script></body>

<!-- Mirrored from seantheme.com/admetro/analytics.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Mar 2021 07:06:02 GMT -->
</html>