<?php
/**
 * Created by PhpStorm.
 * User: freshbakerycongo
 * Date: 2019-03-28
 * Time: 16:41
 */
?>
<header id="header" class="app-header">

<button type="button" class="navbar-toggle navbar-toggle-minify" data-click="sidebar-minify">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>


<div class="navbar-header">
    <a href="index.html" class="navbar-brand">
    Grow Africa Foundation
    </a>
    <button type="button" class="navbar-toggle" data-click="sidebar-toggled">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
</div>
<ul class="navbar-nav navbar-right">
    <li class="nav-item dropdown">
        <a href="#" data-toggle="dropdown" data-display="static" class="nav-link">
            <span class="nav-img online">
                <img src="assets/img/user.jpg" alt="" />
            </span>
            <span class="d-none d-md-block"><?php echo $user->data()->nom." ".$user->data()->prenom; ?> <b class="caret"></b></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="edit-profile.php">Editer le profil</a>
            <a class="dropdown-item" href="#">Boîte de réception</a>
            <a class="dropdown-item" href="#">Calendrier</a>
        <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="logout.php">Se déconnecter</a>
        </div>
    </li>
</ul>
</header>