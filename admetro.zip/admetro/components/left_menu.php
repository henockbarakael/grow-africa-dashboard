<?php
/**
 * Created by PhpStorm.
 * User: freshbakerycongo
 * Date: 2019-03-28
 * Time: 17:31
 */
//session_start();
?>
<aside class="main-sidebar">
    <!-- Barre de menu gauche -->
    <section class="sidebar">
        <?php
        if (strstr(strtolower($user->data()->firstname), '1xbet') != false) {
            $logo = '1xbet.png';
        } elseif (strstr(strtolower($user->data()->firstname), 'premier') != false) {
            $logo = 'premier.png';
        } elseif (strstr(strtolower($user->data()->firstname), 'fpadmin') != false) {
            $logo = 'avatar5.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'HerveM') != false) {
            $logo = 'avatar5.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), '1xbet_admin') != false) {
            $logo = '1xbet.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'PremierBet') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'maxicash') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'DiamantNer') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'DoveGroupe') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'Oink') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), '1xbetClient') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'SupportTest') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'BisoExpress') != false) {
            $logo = 'avatar5.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'PlayUsMedia') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'RT-Group') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'QNET') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'kids4educ') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'NDULEMART SARL') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'Mobinprotect') != false) {
            $logo = 'avatar.png';
        }
        elseif (strstr(strtolower($user->data()->firstname), 'Mprotect') != false) {
            $logo = 'avatar.png';
        }
        ?>
        <!-- user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="dist/img/<?php echo $logo; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo $user->data()->firstname; ?></p>
                <a href="#">
                    <?php if ($user->data()->status == 1) { ?>
                        <i class="fa fa-circle text-success"></i> Actif
                    <?php } else { ?>
                        <i class="fa fa-circle text-success"></i> Non Actif
                    <?php } ?>
                </a>
            </div>
        </div>
        <!-- sidebar menu -->
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>

            <?php
            if ($user->data()->niveau == 0 && $user->data()->institution_code == 'isgY0XhXgHkQzc8pd') {
                ?>
            <li class="<?php if($_SESSION['isActivePage'] == 'mb-admin' || $_SESSION['isActivePage'] == 'fp-all-transactions' || $_SESSION['isActivePage'] == 'mb-user'){ echo 'active'; } ?> treeview">
                <a href="mb-admin.php">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span></i>
                </a>
            </li>

                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-laptop"></i>
                        <span>Configurations</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="pages/UI/general.html"><i class="fa fa-circle-o"></i> administrer les Merchants</a></li>
                        <li><a href="pages/UI/general.html"><i class="fa fa-circle-o"></i> administrer les Users</a></li>
                        <li><a href="pages/UI/general.html"><i class="fa fa-circle-o"></i> administrer les Institutions</a></li>
                    </ul>
                </li>

                <li class="treeview <?php if($_SESSION['isActivePage'] == 'fp-wallets'){ echo 'active';}?>">
                    <a href="#">
                        <i class="fa fa-table"></i> <span>Business Reports</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-wallets'){ echo 'active';}?>"><a href="fp-wallets.php"><i class="fa fa-circle-o"></i> Etat des wallets</a></li>
                        <li><a href="pages/tables/data.html"><i class="fa fa-circle-o"></i> Etat des wallets par Merchant</a></li>
                        <li><a href="pages/tables/data.html"><i class="fa fa-circle-o"></i> Etat des commissions</a></li>
                    </ul>
                </li>
                <li class="treeview <?php if($_SESSION['isActivePage'] == 'fp-paiements' || $_SESSION['isActivePage'] == 'fp-banques'){ echo 'active';}?>">
                    <a href="#">
                        <i class="fa fa-folder"></i> <span>Paiements & Transferts</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-paiements'){ echo 'active';}?>"><a href="fp-paiements.php"><i class="fa fa-circle-o"></i> Compte a Compte</a></li>
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-banques'){ echo 'active';}?>"><a href="fp-banques.php"><i class="fa fa-circle-o"></i> Compte a Banque</a></li>
                        <li><a href="pages/examples/login.html"><i class="fa fa-circle-o"></i> Login</a></li>
                        <li><a href="pages/examples/register.html"><i class="fa fa-circle-o"></i> Register</a></li>
                        <li><a href="pages/examples/lockscreen.html"><i class="fa fa-circle-o"></i> Lockscreen</a></li>
                        <li><a href="pages/examples/404.html"><i class="fa fa-circle-o"></i> 404 Error</a></li>
                        <li><a href="pages/examples/500.html"><i class="fa fa-circle-o"></i> 500 Error</a></li>
                        <li><a href="pages/examples/blank.html"><i class="fa fa-circle-o"></i> Blank Page</a></li>
                        <li><a href="pages/examples/pace.html"><i class="fa fa-circle-o"></i> Pace Page</a></li>
                    </ul>
                </li>
                <li class="<?php if($_SESSION['isActivePage'] == 'fp-transactions'){ echo 'active';}?>"><a href="fp-transactions.php"><i class="fa fa-book"></i> <span>Historique des transactions</span></a></li>

                <?php
            } else if ($user->data()->niveau == 0){
                ?>
                <li class="<?php if($_SESSION['isActivePage'] == 'mb-admin' || $_SESSION['isActivePage'] == 'fp-all-transactions' || $_SESSION['isActivePage'] == 'mb-user'){ echo 'active'; } ?> treeview">
                <a href="mb-user.php">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span></i>
                </a>
            </li>
            <li class="treeview <?php if($_SESSION['isActivePage'] == 'fp-user-paiements' || $_SESSION['isActivePage'] == 'fp-user-banques'){ echo 'active';}?>">
                    <a href="#">
                        <i class="fa fa-folder"></i> <span>Payment & Transfert</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-user-paiements'){ echo 'active';}?>"><a href="fp-user-paiements.php"><i class="fa fa-circle-o"></i> Wallet to Wallet</a></li>
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-user-banques'){ echo 'active';}?>"><a href="fp-user-banques.php"><i class="fa fa-circle-o"></i> Wallet to Bank</a></li>
                    </ul>
                </li>
                <li class="treeview <?php if($_SESSION['isActivePage'] == 'fp-wallets-user' || $_SESSION['isActivePage'] == 'fp-monthly-recap'){ echo 'active';}?>">
                    <a href="#">
                        <i class="fa fa-table"></i> <span>Business Reports</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php if($_SESSION['isActivePage'] == 'fp-monthly-recap'){ echo 'active';}?>"><a href="fp-user-recap.php"><i class="fa fa-circle-o"></i> Monthly & Balance Report</a></li>
                    </ul>
                </li>
                <li class="<?php if($_SESSION['isActivePage'] == 'fp-user-transactions'){ echo 'active';}?>"><a href="fp-user-transactions.php"><i class="fa fa-book"></i> <span>Transactions history</span></a></li>
                <?php
            } else if ($user->data()->niveau > 0) {
            ?>
            <li class="<?php if($_SESSION['isActivePage'] == 'mb-admin' || $_SESSION['isActivePage'] == 'fp-all-transactions' || $_SESSION['isActivePage'] == 'mb-user'){ echo 'active'; } ?> treeview">
                <a href="mb-user.php">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span></i>
                </a>
            </li>
                <li class="<?php if($_SESSION['isActivePage'] == 'fp-user-transactions'){ echo 'active';}?>"><a href="fp-user-transactions.php"><i class="fa fa-book"></i> <span>Transactions history</span></a></li>
            <?php
            }
            ?>
        </ul>
    </section>
    <!-- /.sidebar fp-wallets-user -->
</aside>
