<?php
/**
 * Created by PhpStorm.
 * User: freshbakerycongo
 * Date: 2019-03-28
 * Time: 17:41
 */
?>
<header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo" style="background-color: #E14523;">
        <span class="logo-mini"><b>Fresh</b>Pay</span>
        <span class="logo-lg"><b>Fresh</b>Pay</span>
    </a>
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation" style="background-color: #643416;">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle de navigation</span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- Messages à revoir aussi -->
                <li class="dropdown messages-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-envelope-o"></i>
                        <span class="label label-success">0</span>
                    </a>
                </li>
                <!-- Notifications -->
                <li class="dropdown notifications-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-bell-o"></i>
                        <span class="label label-warning">0</span>
                    </a>
                </li>
                <!-- Tâches  -->
                <li class="dropdown tasks-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-flag-o"></i>
                        <span class="label label-danger">0</span>
                    </a>
                </li>
                
                <!-- User Account -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <?php 
                        if (strstr(strtolower($user->data()->firstname), '1xbet') != false) {
                            $logo = '1xbet.png';
                        } elseif (strstr(strtolower($user->data()->firstname), 'premier') != false) {
                            $logo = 'premier.png';
                        } elseif (strstr(strtolower($user->data()->firstname), 'fpadmin') != false) {
                            $logo = 'avatar5.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'HerveM') != false) {
                            $logo = 'avatar5.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), '1xbet_admin') != false) {
                            $logo = '1xbet.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'PremierBet') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'maxicash') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'DiamantNer') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'DoveGroupe') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'Oink') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), '1xbetClient') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'SupportTest') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'BisoExpress') != false) {
                            $logo = 'avatar5.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'PlayUsMedia') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'RT-Group') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'QNET') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'kids4educ') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'NDULEMART SARL') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'Mobinprotect') != false) {
                            $logo = 'avatar.png';
                        }
                        elseif (strstr(strtolower($user->data()->firstname), 'Mprotect') != false) {
                            $logo = 'avatar.png';
                        }
                        echo $user->data()->firstname; ?>
                        <img src="dist/img/<?php echo $logo; ?>" class="user-image" alt="User Image">
                        <span class="hidden-xs"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <img src="dist/img/<?php echo $logo; ?>" class="img-circle" alt="User Image">

                            <p>
                                <?php echo $user->data()->firstname; ?>
                                <small><?php echo $user->data()->niveau; ?></small>
                            </p>
                        </li>

                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-right">
                                <a href="logout.php" class="btn btn-default btn-flat">Deconnexion</a>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>
