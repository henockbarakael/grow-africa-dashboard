<?php
/**
 * Created by PhpStorm.
 * User: freshbakerycongo
 * Date: 2019-03-28
 * Time: 23:21
 */

//Utiliser les sessions pour connaitre le lieu de navigation pour l'afficher Ex.: Accueil > DashBoard
?>
<section class="content-header">
    <h1>
        Dashboard
        <small>Panneau de contrôle</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Accueil</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>

<!--<section class="content-header">
    <h1>
        404 Error Page
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">404 error</li>
    </ol>
</section>-->