<?php
/**
 * Created by PhpStorm.
 * User: freshbakerycongo
 * Date: 2019-03-28
 * Time: 17:31
 */
//session_start();
?>
<sidebar id="sidebar" class="app-sidebar">

<div data-scrollbar="true" data-height="100%">

<ul class="nav">
<li class="nav-profile">
<div class="profile-img">
<img src="assets/img/user.jpg" />
</div>
<div class="profile-info">
<h4><?php echo $user->data()->nom." ".$user->data()->prenom; ?></h4>
<p>Footballeur</p>
</div>
</li>
<li class="nav-divider"></li>
<li class="nav-header">Navigation</li>
<li>
    <a href="index.php">
    <span class="nav-icon"><i class="fa fa-th-large"></i></span>
    <span class="nav-text">Accueil</span>
    </a>
</li>
<li class="nav-divider"></li>

<li class="nav-header">Gestion des joueurs</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-purple text-white"></i></span>
        <span class="nav-text">Tous les joueurs</span>
    </a>
</li>
<li class="has-sub">
    <a href="#">
    <span class="nav-icon"><i class="fa fa-list bg-gradient-orange text-white"></i></span>
    <span class="nav-text">Liste des joueurs</span>
    <span class="nav-caret"><b class="caret"></b></span>
    </a>
    <ul class="nav-submenu">
        <li><a href="#"><span class="nav-text">U20</span></a></li>
        <li><a href="#"><span class="nav-text">U17</span></a></li>
        <li><a href="#"><span class="nav-text">U15</span></a></li>
    </ul>
</li>
<li class="has-sub">
    <a href="#">
    <span class="nav-icon"><i class="fa fa-list bg-gradient-red text-white"></i></span>
    <span class="nav-text">Liste des joueuses</span>
    <span class="nav-caret"><b class="caret"></b></span>
    </a>
    <ul class="nav-submenu">
        <li><a href="#"><span class="nav-text">U20</span></a></li>
        <li><a href="#"><span class="nav-text">U17</span></a></li>
        <li><a href="#"><span class="nav-text">U15</span></a></li>
    </ul>
</li>

<li class="nav-divider"></li>

<li class="nav-header">Gestion entraîneurs</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-blue text-white"></i></span>
        <span class="nav-text">Liste des entraîneurs</span>
    </a>
</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-purple text-white"></i></span>
        <span class="nav-text">Ajouter entraîneur</span>
    </a>
</li>
<li class="nav-divider"></li>

<li class="nav-header">Gestion des arbitres</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-orange text-white"></i></span>
        <span class="nav-text">Liste des arbitres</span>
    </a>
</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-red text-white"></i></span>
        <span class="nav-text">Ajouter un arbitre</span>
    </a>
</li>
<li>
    <a href="#">
        <span class="nav-icon"><i class="fa fa-list bg-gradient-blue text-white"></i></span>
        <span class="nav-text">Nombre de match arbitré</span>
    </a>
</li>
<li class="nav-divider"></li>
<li class="nav-copyright">&copy; 2021 Grow Africa Foundation Tous droits réservés</li>
</ul>

</div>

</sidebar>