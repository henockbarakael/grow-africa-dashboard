<?php

class Update
{
    private $_db,
            $_data,
            $_sessionName,
            $_cookieName,
            $_isLoggedIn = false;

    public function __construct($user = null)
    {
        $this->_db = DB::getInstance();
        $_sessionName = Config::get('session/session_name');
        $_cookieName = Config::get('remember/cookie_name');

        if (!$user) {
            if (Session::exists($this->_sessionName)) {
                $user = Session::get($this->_sessionName);

                if ($this->find($user)) {
                    $this->_isLoggedIn = true;
                }else {

                }
            }
        }else {
            $this->find($user);
        }
    }

    public function isLoggedIn(){
        return $this->_isLoggedIn;
    }
    
    public function find($user = null){
        if ($user) {
            $field = (is_numeric($user)) ? 'id' : 'code';
            $data = $this->_db->get('user_profile', array($field, '=', $user));


            if ($data->count()) {
                $this->_data = $data->getFirst();
                return true;
            }
        }

        return false;
    }

    public function update($fields = array(), $chosenfield = 'code',$code = null){
        if(!$code && $this->isLoggedIn()) {
            $code = $this->data()->code;
          }
          
        if(!$this->_db->update('user_profile', $chosenfield, $code, $fields)){
            throw new Exception('Il y a eu un problème dans la mise à jour de votre profil.');
        }
    }


    public function exists()
    {
        return (!empty($this->_data)) ? true : false;
    }

    public function data()
    {
        return $this->_data;
    }

}
?>