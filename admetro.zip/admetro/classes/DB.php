<?php
class DB
{
    private static $_instance = null;
    private $_pdo,
            $_query,
            $_error = false,
            $_results,
            $_count = 0;

    private function __construct()
    {
        try {
            //$this->_pdo = new PDO()
            $this->_pdo = new PDO('mysql:host='. Config::get('mysql/host').';dbname='.Config::get('mysql/db').';port='.Config::get('mysql/port'), Config::get('mysql/username'), Config::get('mysql/password'), array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
        } catch (PDOException $th) {
            die($th->getMessage());
        }
    }

    public static function getInstance()
    {
        if (!isset(self::$_instance)) {
            self::$_instance = new DB();
        }

        return self::$_instance;
    }

    public function query($sql, $param = array())
    {
        $this->_error = false;
        if ($this->_query = $this->_pdo->prepare($sql)) {
            $x = 1;
            if (count($param)) {
                foreach ($param as $para) {
                    $this->_query->bindValue($x, $para);
                    $x++;
                }
            }

            if ($this->_query->execute()) {
                $this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
                $this->_count = $this->_query->rowCount();
            } else {
                $this->_error = true;
            }
        }

        return $this;
    }

    public function error()
    {
        return $this->_error;
    }

    public function action($action, $table, $where = array())
    {
        
        if (count($where) == 3) {
            $operators = array('=', '>', '<', '>=', '<=');
            $field = $where[0];
            $operator = $where[1];
            $value = $where[2];

            if (in_array($operator, $operators)) {
                $sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";
                if(!$this->query($sql, array($value))->error())
                {
                    return $this;
                }
            }
        }

        return false;
    }

    public function get($table, $where)
    {
        return $this->action("SELECT *", $table, $where);
    }

    public function delete($table, $where)
    {
        return $this->action('DELETE ', $table, $where);
    }

    public function count()
    {
        return $this->_count;
    }

    public function result()
    {
        return $this->_results;
    }

    public function getFirst()
    {
        return $this->result()[0];
    }

    public function insert($table, $fiedls = array())
    {
        if(count($fiedls))
        {
            $keys = array_keys($fiedls);
            $values = '';
            $x = 1;

            foreach ($fiedls as  $fiedl) {
                $values .= '?';
                if ($x < count($fiedls)) {
                    $values .= ', ';
                }
                $x++;
            }

        $sql = "INSERT INTO {$table}(`". implode('`,`', $keys)."`) VALUES({$values})";
        if (!$this->query($sql, $fiedls)->error()) {
            return true;
        }
        }

        return false;
    }

    public function update($table,  $chosenfield, $id, $tableau)
    {
        $set = '';
        $x = 1;

        foreach ($tableau as $name => $tab) {
            $set .= "{$name} = ?";
            if($x < count($tableau))
            {
                $set .= ', ';
            }

            $x++;
        }


        $sql = "UPDATE {$table} SET {$set} WHERE {$chosenfield} = ?";

        // Create the prepared statement
        $stmt = $this->_pdo->prepare($sql);

        // Bind each parameter
        for($i=0; $i<count($tableau); $i++)
        ini_set('memory_limit', '-1');
            $stmt->bindParam($i+1, $tableau[$i]);

        // Copy the last one
       // $stmt->bindParam($i+1, $id);
        echo $sql, '<br>';
        echo $set, '<br>';
        var_dump($tableau); '<br>';
        echo $id, '<br>';
        echo $chosenfield, '<br>';
        // The execute call tells whether or not the query was successful
        if($stmt->execute()){
        return true;
        }
        return false;
    }
}

