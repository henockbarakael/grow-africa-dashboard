<?php

class Transfert
{
    private $_db,
            $_data;

    public function __construct($transfert = null)
    {
        $this->_db = DB::getInstance();
    }

    public function create($fields = array())
    {
        if(!$this->_db->insert('drc_send_money_transfert', $fields))
        {
            throw new Exception('There was a problem creating an transfert.');

        }
    }


    public function exists()
    {
        return (!empty($this->_data)) ? true : false;
    }

    public function data()
    {
        return $this->_data;
    }

}
