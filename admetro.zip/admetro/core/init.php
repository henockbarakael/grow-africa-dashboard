<?php

session_start();
//134.209.241.115
//161.35.29.153

/**$HOST_OR = '157.90.55.60';
$USER_OR = 'growafri_admin';
$DB_OR = 'growafri_inscription';
$PASSWORD_OR = '4n5B:LY6e[w4gR';
$PORT_OR = 3306;**/

$HOST_OR = 'localhost';
$USER_OR = 'root';
$DB_OR = 'growafricardc';
$PASSWORD_OR = '';
$PORT_OR = 3306;

$GLOBALS['config'] = array(
    'mysql' => array(
        'host' => $HOST_OR,
        'username' => $USER_OR,
        'password' => $PASSWORD_OR,
        'db' => $DB_OR,
        'port' => $PORT_OR
    ),
    'remember' => array(
        'cookie_name' => 'freshpay',
        'cookie_expiry' => 86400
    ),
    'session' => array(
        'session_name' => 'user',
        'token_name' => 'token_freshpay'
    )
    );
spl_autoload_register(function($class){
    require_once 'classes/'. $class. '.php';
});

require_once 'functions/sanitize.php';

if (Cookie::exists(Config::get('remember/cookie_name')) && !Session::exists(Config::get('session/session_name'))) {
    $hash = Cookie::get(Config::get('remember/cookie_name'));

    $hashCheck = DB::getInstance()->get('table_session', array('hash', '=', $hash));

    if ($hashCheck->count()) {
        $user =new User($hashCheck->getFirst()->id);
        $user->login();
    }
}